# R-MRP synthetic reference implementation

This executable model is an illustrative rule-based multi-AZ resource-placement
and service-chain admission controller. All capacities, costs and latencies are
synthetic inputs. The outputs are model results, not AWS benchmarks, measured 5G
performance, availability guarantees, or production deployment evidence.

## Implemented scope

The user-plane chain is an ingress endpoint → UPF processing host → DATA host.
Each complete chain is placed within one availability zone. Two complete replicas
must occupy different permitted zones. The DATA host can represent a data-network
application; an IMS/SIP service could reside there. AMF and SMF are control-plane
functions and must not be described as sequential user-packet hops. This code does
not simulate those functions, radio protocols, packet processing, an IMS stack,
cloud APIs, auto scaling or runtime failover. A general variable-length chain with
separate firewall/IMS resource demands is a future extension, not an implemented
claim.

Hosts are explicitly assigned to a tenant. Placement requires exact tenant
identity, permitted role and permitted AZ. The model represents isolation as a
placement eligibility rule; real network, storage, identity and cryptographic
isolation would require additional enforcement. Four independent host dimensions
are reserved: CPU, memory, disk and processing throughput. Tenant CPU quota is
checked before searching. Each replica reserves the full requested traffic rate
on every directed path edge, including existing requests' reservations.

## Exact fixture

Six hosts: UA/DA in A, UB/DB in B and UC/DC in C. U hosts permit UPF; D hosts permit
DATA. Every host belongs to alpha and has 8 vCPU, 32 GiB RAM, 200 GiB disk and
1,000 Mbit/s processing throughput. Per role per replica the request requires
2 vCPU, 4 GiB RAM, 10 GiB disk and 100 Mbit/s processing. Two replicas therefore
require 8 vCPU, 16 GiB RAM, 40 GiB disk and 400 Mbit/s processing in aggregate.
The processing requirement is an independent synthetic host constraint, distinct
from the 20 Mbit/s traffic reservation per replica. Alpha's CPU quota is 16 vCPU.

Directed fabric: INGRESS→S is 1 ms and 80 Mbit/s; S→RA/RB/RC is respectively
1/3/6 ms and 100 Mbit/s; each router has a separate directed link to and from each
of its two local hosts, with 1 ms latency and 100 Mbit/s capacity. UPF→DATA
travels through the local router. Consequently, complete chain latencies are
A=5 ms, B=7 ms and C=10 ms. The request limit is 12 ms. Processing and queuing
delays are not modeled; reported latency is the sum of fixed link inputs.

Two replicas use the shared ingress trunk at 2×20=40 Mbit/s per request. That
traffic is deliberately counted twice: independently provisioned replicated
streams must both fit the trunk. There is no multicast/shared-prefix traffic
deduplication rule in this model. Router→UPF and UPF→router are different directed
links, with independent capacity accounting.

## Preference, search and trace

Every hard-eligible candidate is ranked by

`score = 50 h + 30 (1 − L / Lmax) + 20 (1 − cAZ)`

where h is the mean residual CPU fraction on UPF and DATA hosts **after** placing
this replica, L is fixed chain latency, Lmax is the request's latency limit and
cAZ is the normalized preference input (A=.6, B=.3, C=.1). Cost inputs are
dimensionless policy values, not currency or AWS prices. Memory/disk/throughput
remain mandatory constraints even though they do not contribute to the score.
Ties are broken by ascending AZ, UPF host ID, then DATA host ID.

Initially h=(8−2)/8=.75 in every zone. A scores 37.5+17.5+8=63.0;
B scores 37.5+12.5+14=64.0; C scores 37.5+5+18=60.5. The first request selects
B and then A in two search expansions. The complete plan is committed as one
returned snapshot: tenant CPU=8 and ingress trunk=40 Mbit/s.

The next request sees A/B residual fraction (8−2−2)/8=.5 and C fraction .75.
Its scores are C=60.5, B=51.5 and A=50.5, so it selects C then B. The resulting
tenant CPU is 16; the trunk is exactly 80 Mbit/s. Host CPU allocations are
UA/DA=2 each, UB/DB=4 each, UC/DC=2 each. A third identical request fails the
16-vCPU quota. Raising the quota to 100 allows that check to pass, but the third
request is still rejected because the shared trunk has no residual bandwidth.

The planner performs depth-first, preference-ordered bounded backtracking over
whole-chain candidates. Each candidate uses a copied snapshot; a failed later
resource or path allocation cannot leak earlier reservations. Failed replica
branches are rolled back by discarding their snapshots. The input state is never
modified, even on success; callers replace their active snapshot only when
`result.accepted` is true. Returning the first feasible plan is a heuristic, not
a proof of minimum cost or globally optimal placement. SEARCH_BUDGET denotes
incomplete search and must not be interpreted as a proof of infeasibility.

Routes use deterministic shortest latency, with lexicographic edge-path ties.
Residual bandwidth is checked on those fixed routes. A rejected request might
be feasible under a different routing policy or more permissive locality rule.
Concurrent admissions need an external lock or compare-and-swap state version;
this single-process model does not implement concurrency control.

## Complexity

Let H be hosts, V/E fabric vertices/edges, C eligible whole-chain candidates,
R replicas, L the maximum path length and S the number of allocation counters.
This two-role implementation enumerates at most H² host pairs and runs two
Dijkstra searches per eligible pair, taking O(H²(E+V) log V) preprocessing in the
worst case, plus candidate/path storage. Without a limit, search can explore
O(C^R) assignments. With at most B attempted expansions (default 64), the
implementation is bounded by O(B(C log C + S + L)) after preprocessing: ranking
and copying snapshots dominate. Search storage is O(RS + CL + B) including
snapshots, candidate paths and the trace, apart from the input graph. These are
implementation bounds, not a polynomial optimal-placement guarantee.

## Reproduce

Run `python -m unittest -v test_planner.py`, then `python planner.py` from this
directory. `metrics.json` records the exact fixture, complete first and second
plans, allocation snapshots, traces and third-request rejection outcomes.
The 13 tests cover successful admission and arithmetic; tenant quota; all four
host resource limits; tenant denial; latency rejection; permitted AZ diversity;
determinism; cumulative CPU; aggregate bandwidth; rollback after partial
reservation; search-budget behavior; and function-role filtering. Malformed-input
subcases cover NaN, infinity, nonpositive values, booleans, noninteger replica
counts, invalid AZ collections and missing identity/resource fields. Validation
occurs before any reservation. `test_results.txt` preserves the complete run.
