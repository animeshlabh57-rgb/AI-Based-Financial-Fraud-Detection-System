"""Behavioral tests for the synthetic R-MRP reference implementation."""
from copy import deepcopy
import unittest

from planner import Planner, Request, State, fixture


class PlannerTests(unittest.TestCase):
    def test_success_score_latency_and_reservations(self):
        result = fixture().admit(State(), Request())
        self.assertTrue(result.accepted)
        self.assertEqual([p["zone"] for p in result.placements], ["B", "A"])
        self.assertEqual([p["score"] for p in result.placements], [64, 63])
        self.assertEqual([p["latency"] for p in result.placements], [7, 5])
        self.assertEqual(result.state.link_used["INGRESS>S"], 40)
        self.assertEqual(result.state.tenant_cpu["alpha"], 8)

    def test_tenant_cpu_quota_is_atomic(self):
        state = State()
        result = fixture(quota=7).admit(state, Request())
        self.assertEqual(result.reason, "QUOTA")
        self.assertEqual(state, State())
        self.assertEqual(result.state, state)

    def test_all_four_host_resource_dimensions_are_hard_constraints(self):
        for resource in ("cpu", "memory", "disk", "throughput"):
            with self.subTest(resource=resource):
                planner = fixture()
                for host in planner.hosts.values():
                    if "UPF" in host.roles:
                        host.capacity[resource] = Request().demands["UPF"][resource] - .5
                result = planner.admit(State(), Request())
                self.assertFalse(result.accepted)
                self.assertEqual(result.state, State())

    def test_cross_tenant_host_placement_is_denied(self):
        result = fixture().admit(State(), Request(tenant="beta"))
        self.assertEqual(result.reason, "NO_ELIGIBLE_CHAIN")

    def test_impossible_end_to_end_latency_is_denied(self):
        result = fixture().admit(State(), Request(latency_limit=4))
        self.assertEqual(result.reason, "NO_ELIGIBLE_CHAIN")

    def test_two_replicas_require_distinct_permitted_azs(self):
        result = fixture().admit(State(), Request(allowed_zones=("A",)))
        self.assertEqual(result.reason, "AZ_DIVERSITY")
        accepted = fixture().admit(State(), Request(allowed_zones=("A", "C")))
        self.assertEqual({p["zone"] for p in accepted.placements}, {"A", "C"})

    def test_same_input_has_identical_plan_and_trace(self):
        planner = fixture()
        self.assertEqual(planner.admit(State(), Request()), planner.admit(State(), Request()))

    def test_cumulative_cpu_is_preserved_across_admissions(self):
        planner = fixture()
        first = planner.admit(State(), Request())
        second = planner.admit(first.state, Request(id="MSP-002"))
        self.assertTrue(second.accepted)
        self.assertEqual(second.state.tenant_cpu["alpha"], 16)
        self.assertEqual([p["zone"] for p in second.placements], ["C", "B"])
        for host in ("UA", "DA", "UC", "DC"):
            self.assertEqual(second.state.host_used[host]["cpu"], 2)
        for host in ("UB", "DB"):
            self.assertEqual(second.state.host_used[host]["cpu"], 4)
        self.assertEqual(first.state.tenant_cpu["alpha"], 8)

    def test_shared_trunk_counts_both_replicas_and_existing_requests(self):
        planner = fixture(quota=100)
        first = planner.admit(State(), Request())
        second = planner.admit(first.state, Request(id="MSP-002"))
        before = deepcopy(second.state)
        third = planner.admit(second.state, Request(id="MSP-003"))
        self.assertFalse(third.accepted)
        self.assertEqual(second.state.link_used["INGRESS>S"], 80)
        self.assertEqual(second.state, before)
        self.assertEqual(third.state, before)
        self.assertTrue(any("bandwidth exhausted" in line for line in third.trace))

    def test_late_failure_rolls_back_partial_replica_and_host_allocations(self):
        state = State()
        result = fixture(trunk_capacity=30).admit(state, Request())
        self.assertFalse(result.accepted)
        self.assertTrue(any("Rollback replica" in line for line in result.trace))
        self.assertEqual(result.state, State())
        self.assertEqual(state, State())

    def test_search_budget_is_bounded_and_distinguished_from_infeasibility(self):
        result = fixture(max_attempts=1).admit(State(), Request())
        self.assertEqual(result.reason, "SEARCH_BUDGET")
        self.assertEqual(result.attempts, 1)
        self.assertEqual(result.state, State())

    def test_role_filter_removes_ineligible_host(self):
        planner = fixture()
        planner.hosts["UB"].roles = ("DATA",)
        result = planner.admit(State(), Request())
        self.assertTrue(result.accepted)
        self.assertEqual([p["zone"] for p in result.placements], ["A", "C"])

    def test_malformed_requests_are_rejected_before_any_reservation(self):
        requests = []
        for value in (float("nan"), float("inf"), -1, 0, True, "2"):
            requests.extend((Request(bandwidth=value), Request(latency_limit=value)))
            request = Request()
            request.demands["UPF"]["cpu"] = value
            requests.append(request)
        requests.extend(Request(replicas=value) for value in (1.5, True, -1, 0, float("inf")))
        requests.extend(Request(allowed_zones=value)
                        for value in ("AB", (), ("A", "Z"), ("A", "A"), (True,)))
        requests.extend((Request(tenant=None), Request(id=""), Request(demands=None)))
        for index, request in enumerate(requests):
            with self.subTest(case=index):
                state = State()
                with self.assertRaises(ValueError):
                    fixture().admit(state, request)
                self.assertEqual(state, State())


if __name__ == "__main__":
    unittest.main(verbosity=2)
