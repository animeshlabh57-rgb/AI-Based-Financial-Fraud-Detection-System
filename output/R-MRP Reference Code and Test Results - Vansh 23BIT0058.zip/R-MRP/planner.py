"""R-MRP: deterministic, transactional synthetic placement reference model.

Units: CPU=vCPU; memory/disk=GiB; throughput/bandwidth=Mbit/s; latency=ms.
No AWS APIs, cloud credentials, or real-network measurements are used.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from copy import deepcopy
import heapq
import json
import math
from pathlib import Path

RESOURCES = ("cpu", "memory", "disk", "throughput")


@dataclass
class Host:
    id: str
    zone: str
    tenant: str
    roles: tuple[str, ...]
    capacity: dict[str, float]


@dataclass
class Link:
    source: str
    target: str
    latency: float
    bandwidth: float

    @property
    def key(self):
        return f"{self.source}>{self.target}"


@dataclass
class State:
    host_used: dict[str, dict[str, float]] = field(default_factory=dict)
    link_used: dict[str, float] = field(default_factory=dict)
    tenant_cpu: dict[str, float] = field(default_factory=dict)


@dataclass
class Request:
    id: str = "MSP-001"
    tenant: str = "alpha"
    allowed_zones: tuple[str, ...] = ("A", "B", "C")
    replicas: int = 2
    bandwidth: float = 20
    latency_limit: float = 12
    demands: dict[str, dict[str, float]] = field(default_factory=lambda: {
        "UPF": {"cpu": 2, "memory": 4, "disk": 10, "throughput": 100},
        "DATA": {"cpu": 2, "memory": 4, "disk": 10, "throughput": 100},
    })


@dataclass
class Result:
    accepted: bool
    reason: str
    placements: list[dict]
    state: State
    attempts: int
    trace: list[str]


class Planner:
    """First feasible ordered search, with hard rules before preferences.

    A chain's UPF and DATA are constrained to the same AZ. Replicas occupy
    distinct AZs. Each replica reserves the full requested traffic rate; this
    represents capacity provisioned for failover, not measured traffic.
    Routes are deterministic shortest-latency paths in the supplied graph.
    Rejection does not imply infeasibility under other routing/locality policies.
    """

    def __init__(self, hosts, links, zone_cost, tenant_quota, max_attempts=64):
        self.hosts = {h.id: h for h in hosts}
        self.links = {e.key: e for e in links}
        self.zone_cost = zone_cost
        self.tenant_quota = tenant_quota
        self.max_attempts = max_attempts
        self.graph = {}
        for e in links:
            self.graph.setdefault(e.source, []).append(e)
        for edges in self.graph.values():
            edges.sort(key=lambda e: (e.target, e.key))

    def route(self, source, target):
        # The path tuple makes equal-latency ties deterministic.
        queue = [(0.0, (), source)]
        best = {}
        while queue:
            delay, path, node = heapq.heappop(queue)
            if node in best and best[node] <= (delay, path):
                continue
            best[node] = (delay, path)
            if node == target:
                return delay, path
            for edge in self.graph.get(node, []):
                heapq.heappush(queue, (delay + edge.latency,
                                      path + (edge.key,), edge.target))
        return None

    def admit(self, state: State, request: Request) -> Result:
        def positive_finite(value):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                return False
            try:
                return math.isfinite(value) and value > 0
            except OverflowError:
                return False

        if type(request.replicas) is not int or request.replicas < 1:
            raise ValueError("Replicas must be a positive integer, excluding bool")
        if not positive_finite(request.bandwidth) or not positive_finite(request.latency_limit):
            raise ValueError("Bandwidth and latency must be positive finite numbers")
        if any(not isinstance(value, str) or not value.strip()
               for value in (request.id, request.tenant)):
            raise ValueError("Request ID and tenant must be nonempty strings")
        if (not isinstance(request.allowed_zones, (tuple, list)) or not request.allowed_zones
                or any(not isinstance(z, str) or z not in self.zone_cost
                       for z in request.allowed_zones)
                or len(set(request.allowed_zones)) != len(request.allowed_zones)):
            raise ValueError("Permitted AZs must be a nonempty list/tuple of distinct known AZs")
        if not isinstance(request.demands, dict) or set(request.demands) != {"UPF", "DATA"}:
            raise ValueError("Exactly UPF and DATA roles are supported")
        if any(not isinstance(d, dict) or set(d) != set(RESOURCES)
               or any(not positive_finite(v) for v in d.values())
               for d in request.demands.values()):
            raise ValueError("Each role requires four positive finite resource demands")

        trace = []
        cpu = request.replicas * sum(d["cpu"] for d in request.demands.values())
        if state.tenant_cpu.get(request.tenant, 0) + cpu > self.tenant_quota.get(request.tenant, 0):
            return Result(False, "QUOTA", [], deepcopy(state), 0,
                          [f"Tenant CPU admission would exceed quota: +{cpu:g} vCPU"])
        if len(set(request.allowed_zones)) < request.replicas:
            return Result(False, "AZ_DIVERSITY", [], deepcopy(state), 0,
                          ["Fewer permitted AZs than requested replicas"])

        # Static eligibility: tenant identity, function role, permitted AZ,
        # UPF/DATA AZ locality, route existence, and per-chain latency.
        candidates = []
        for upf in sorted(self.hosts.values(), key=lambda h: h.id):
            if (upf.tenant != request.tenant or "UPF" not in upf.roles
                    or upf.zone not in request.allowed_zones):
                continue
            for data in sorted(self.hosts.values(), key=lambda h: h.id):
                if (data.tenant != request.tenant or "DATA" not in data.roles
                        or data.zone != upf.zone or data.id == upf.id):
                    continue
                first, second = self.route("INGRESS", upf.id), self.route(upf.id, data.id)
                if first is None or second is None:
                    continue
                latency = first[0] + second[0]
                if latency <= request.latency_limit:
                    candidates.append({"zone": upf.zone, "upf": upf.id,
                                       "data": data.id, "latency": latency,
                                       "edges": first[1] + second[1]})
        if not candidates:
            return Result(False, "NO_ELIGIBLE_CHAIN", [], deepcopy(state), 0,
                          ["No chain satisfies tenant, role, AZ and latency rules"])

        attempts, budget_hit = 0, False

        def score(candidate, snapshot):
            headroom = sum((self.hosts[candidate[key]].capacity["cpu"]
                            - snapshot.host_used.get(candidate[key], {}).get("cpu", 0)
                            - request.demands[role]["cpu"])
                           / self.hosts[candidate[key]].capacity["cpu"]
                           for key, role in (("upf", "UPF"), ("data", "DATA"))) / 2
            return (50 * headroom + 30 * (1 - candidate["latency"] / request.latency_limit)
                    + 20 * (1 - self.zone_cost[candidate["zone"]]))

        def reserve(candidate, snapshot):
            # Entire candidate is reserved in a private snapshot. A late failure
            # discards it, including earlier host or path allocations.
            trial = deepcopy(snapshot)
            for key, role in (("upf", "UPF"), ("data", "DATA")):
                host = self.hosts[candidate[key]]
                used = trial.host_used.setdefault(host.id, {})
                for resource, demand in request.demands[role].items():
                    if used.get(resource, 0) + demand > host.capacity[resource]:
                        return None, f"{host.id} {resource} exhausted"
                    used[resource] = used.get(resource, 0) + demand
            for edge_key in candidate["edges"]:
                used = trial.link_used.get(edge_key, 0)
                if used + request.bandwidth > self.links[edge_key].bandwidth:
                    return None, f"{edge_key} bandwidth exhausted"
                trial.link_used[edge_key] = used + request.bandwidth
            return trial, ""

        def search(snapshot, selected):
            nonlocal attempts, budget_hit
            if len(selected) == request.replicas:
                return snapshot, selected
            used_zones = {p["zone"] for p in selected}
            ranked = sorted((c for c in candidates if c["zone"] not in used_zones),
                            key=lambda c: (-score(c, snapshot), c["zone"], c["upf"], c["data"]))
            for candidate in ranked:
                if attempts >= self.max_attempts:
                    budget_hit = True
                    return None
                attempts += 1
                value = score(candidate, snapshot)
                trial, failure = reserve(candidate, snapshot)
                trace.append(f"Try {candidate['zone']}: score={value:.2f}; "
                             f"latency={candidate['latency']:g} ms; "
                             + (failure if failure else "hard rules passed"))
                if trial is None:
                    continue
                selected_candidate = {**candidate, "score": round(value, 6)}
                result = search(trial, selected + [selected_candidate])
                if result is not None:
                    return result
                trace.append(f"Rollback replica in AZ {candidate['zone']}")
                if budget_hit:
                    return None
            return None

        found = search(deepcopy(state), [])
        if found is None:
            return Result(False, "SEARCH_BUDGET" if budget_hit else "CAPACITY_OR_DIVERSITY",
                          [], deepcopy(state), attempts, trace)
        committed, selected = found
        committed.tenant_cpu[request.tenant] = committed.tenant_cpu.get(request.tenant, 0) + cpu
        trace.append(f"Commit all {request.replicas} replicas; tenant CPU +{cpu:g} vCPU")
        return Result(True, "ACCEPTED", selected, committed, attempts, trace)


def fixture(trunk_capacity=80, quota=16, max_attempts=64):
    hosts, links = [], [Link("INGRESS", "S", 1, trunk_capacity)]
    for zone, delay in (("A", 1), ("B", 3), ("C", 6)):
        router = f"R{zone}"
        links.append(Link("S", router, delay, 100))
        for role, prefix in (("UPF", "U"), ("DATA", "D")):
            name = prefix + zone
            hosts.append(Host(name, zone, "alpha", (role,),
                              {"cpu": 8, "memory": 32, "disk": 200, "throughput": 1000}))
            links.extend((Link(router, name, 1, 100), Link(name, router, 1, 100)))
    return Planner(hosts, links, {"A": .6, "B": .3, "C": .1},
                   {"alpha": quota, "beta": quota}, max_attempts)


if __name__ == "__main__":
    planner, initial, request = fixture(), State(), Request()
    result = planner.admit(initial, request)
    second = planner.admit(result.state, Request(id="MSP-002"))
    third = planner.admit(second.state, Request(id="MSP-003"))
    bw_planner = fixture(quota=100)
    bw_third = bw_planner.admit(second.state, Request(id="MSP-003"))
    payload = {
        "scope": "Synthetic reference-model results; no cloud or 5G measurements",
        "units": "vCPU, GiB, Mbit/s, ms",
        "hosts": [asdict(h) for h in planner.hosts.values()],
        "links": [asdict(e) for e in planner.links.values()],
        "zone_cost": planner.zone_cost,
        "quota_vcpu": planner.tenant_quota,
        "request": asdict(request),
        "first_admission": asdict(result),
        "second_admission": asdict(second),
        "third_at_quota_16": {"accepted": third.accepted, "reason": third.reason},
        "third_at_quota_100": {"accepted": bw_third.accepted, "reason": bw_third.reason,
                               "attempts": bw_third.attempts, "trace": bw_third.trace},
        "after_two": {"tenant_cpu": second.state.tenant_cpu,
                      "trunk_mbps": second.state.link_used["INGRESS>S"]},
        "input_state_preserved": initial == State(),
    }
    Path(__file__).with_name("metrics.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"first_zones": [p["zone"] for p in result.placements],
                      "scores": [p["score"] for p in result.placements],
                      "latencies_ms": [p["latency"] for p in result.placements],
                      "after_two": payload["after_two"],
                      "third_quota": third.reason, "third_bandwidth": bw_third.reason}, indent=2))
