R-MRP reference model supporting the extended Network Management case study.
Author: Vansh | 23BIT0058

Python standard library only. No cloud account required.
From this directory run:
python -m unittest -v test_planner.py
python planner.py

13 tests pass. All capacities, link delays and cost inputs are synthetic.
The code models INGRESS -> UPF -> DATA placement and full-rate two-AZ replicas.
It does not deploy AWS resources or simulate 5G/IMS protocols.
See TECHNICAL_NOTE.md for exact assumptions and scope.
